package com.example.gym;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private Button btnSeePlan, btnSeeActivities, btnAbout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        Utils.initTrainings();
        btnSeeActivities.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(MainActivity.this, AllTrainingsActivity.class);
                startActivity(intent);
            }
        });
        btnSeePlan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this, PlanActivity.class);
                startActivity(intent);
            }
        });
    }
    private void initViews(){
        btnSeeActivities=findViewById(R.id.btnSeeActivities);
        btnSeePlan=findViewById(R.id.btnSeePlan);
        btnAbout=findViewById(R.id.btnAbout);
    }
}