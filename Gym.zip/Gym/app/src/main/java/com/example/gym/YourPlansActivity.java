package com.example.gym;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class YourPlansActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_your_plans);
    }
}